#include<bits/stdc++.h>
int main(){
    return 0;
}