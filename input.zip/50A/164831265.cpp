#include<iostream>
int m,n;main(){std::cin>>m>>n;std::cout<<m*n/2;}