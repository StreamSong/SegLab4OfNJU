#include <iostream>
main(){long long n,m;std::cin>>n>>m;std::clog<<m*n/2;}