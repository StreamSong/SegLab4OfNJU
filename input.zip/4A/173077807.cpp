#import<iostream>
main(int n){std::cin>>n;puts(n<3|n%2?"NO":"YES");}