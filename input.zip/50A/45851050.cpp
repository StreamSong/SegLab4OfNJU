#import<cstdio>
int a,b;main(){scanf("%d%d",&a,&b);printf("%d",a+b/2);}