#include <iostream>
main(){int n,m;std::cin>>n>>m;std::clog<<m*n/2;}