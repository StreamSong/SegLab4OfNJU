#import<cstdio>
main(int w){scanf("%d",&w);puts(w<3||w%2?"NO":"YES");}